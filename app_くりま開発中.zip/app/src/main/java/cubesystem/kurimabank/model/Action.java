package cubesystem.kurimabank.model;

/**
 * Created by kurimabank-kurima on 2016/03/22.
 */
public interface Action {

    public String getSummary();
}
