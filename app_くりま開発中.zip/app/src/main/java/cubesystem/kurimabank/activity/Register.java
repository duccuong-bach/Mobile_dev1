package cubesystem.kurimabank.activity;

/**
 * Created by sayaka-kurima on 2016/09/07.
 */
public class Register {
}
